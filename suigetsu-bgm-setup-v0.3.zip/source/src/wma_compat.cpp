#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <mferror.h>
#include <objbase.h>
#include <cstdio>
#include <cstdarg>
#include <cwchar>
#include <vector>
#include <atomic>
#include <new>
#include "legacy.h"
#include "pcm_core.h"
#include "bgm_path.h"

static HMODULE dllModule;
static void logPath(const char* label, const WCHAR* path);
static void logLine(const char* pattern, ...) {
    WCHAR path[MAX_PATH];
    if (!GetModuleFileNameW(dllModule, path, MAX_PATH)) return;
    WCHAR* slash = wcsrchr(path, L'\\');
    if (!slash) return;
    const WCHAR filename[] = L"suigetsu-wma-compat.log";
    if (slash - path + 1 + wcslen(filename) >= MAX_PATH) return;
    wcscpy(slash + 1, filename);
    char text[1024];
    va_list args; va_start(args, pattern);
    int length = vsnprintf(text, sizeof(text) - 3, pattern, args);
    va_end(args);
    if (length < 0) return;
    length = static_cast<int>(std::min<std::size_t>(length, sizeof(text) - 3));
    text[length++] = '\r'; text[length++] = '\n';
    HANDLE file = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                              nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) return;
    DWORD written; WriteFile(file, text, length, &written, nullptr); CloseHandle(file);
}
static void logPath(const char* label, const WCHAR* path) {
    char utf8[MAX_PATH * 4];
    if (path && WideCharToMultiByte(CP_UTF8, 0, path, -1, utf8, sizeof(utf8), nullptr, nullptr))
        logLine("%s: %s", label, utf8);
    else logLine("%s: (path conversion failed)", label);
}

template<class T> struct ComPtr {
    T* p = nullptr;
    ~ComPtr() { if (p) p->Release(); }
    T** out() { return &p; }
    T* operator->() const { return p; }
};
struct Runtime {
    bool com = false, mf = false;
    HRESULT init() {
        HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        if (FAILED(hr) && hr != RPC_E_CHANGED_MODE) return hr;
        com = SUCCEEDED(hr);
        hr = MFStartup(MF_VERSION, MFSTARTUP_FULL);
        mf = SUCCEEDED(hr); return hr;
    }
    ~Runtime() { if (mf) MFShutdown(); if (com) CoUninitialize(); }
};

static HRESULT decode(const WCHAR* filename, std::vector<BYTE>& pcmData, WAVEFORMATEX& format) {
    Runtime runtime;
    HRESULT hr = runtime.init();
    if (FAILED(hr)) { logLine("Runtime init failed 0x%08lx", hr); return hr; }
    ComPtr<IMFSourceReader> source;
    hr = MFCreateSourceReaderFromURL(filename, nullptr, source.out());
    if (FAILED(hr)) { logLine("Source open failed 0x%08lx", hr); return hr; }
    hr = source->SetStreamSelection(MF_SOURCE_READER_ALL_STREAMS, FALSE);
    if (FAILED(hr)) return hr;
    hr = source->SetStreamSelection(MF_SOURCE_READER_FIRST_AUDIO_STREAM, TRUE);
    if (FAILED(hr)) return hr;
    ComPtr<IMFMediaType> requested;
    hr = MFCreateMediaType(requested.out());
    if (FAILED(hr)) return hr;
    if (FAILED(hr = requested->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Audio))) return hr;
    if (FAILED(hr = requested->SetGUID(MF_MT_SUBTYPE, MFAudioFormat_PCM))) return hr;
    if (FAILED(hr = requested->SetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE, 16))) return hr;
    hr = source->SetCurrentMediaType(MF_SOURCE_READER_FIRST_AUDIO_STREAM, nullptr, requested.p);
    if (FAILED(hr)) { logLine("PCM output selection failed 0x%08lx", hr); return hr; }
    ComPtr<IMFMediaType> actual;
    hr = source->GetCurrentMediaType(MF_SOURCE_READER_FIRST_AUDIO_STREAM, actual.out());
    if (FAILED(hr)) return hr;
    UINT32 rate = 0, channels = 0, bits = 0, alignment = 0, average = 0;
    if (FAILED(hr = actual->GetUINT32(MF_MT_AUDIO_SAMPLES_PER_SECOND, &rate))) return hr;
    if (FAILED(hr = actual->GetUINT32(MF_MT_AUDIO_NUM_CHANNELS, &channels))) return hr;
    if (FAILED(hr = actual->GetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE, &bits))) return hr;
    if (FAILED(hr = actual->GetUINT32(MF_MT_AUDIO_BLOCK_ALIGNMENT, &alignment))) return hr;
    if (FAILED(hr = actual->GetUINT32(MF_MT_AUDIO_AVG_BYTES_PER_SECOND, &average))) return hr;
    if (channels > UINT16_MAX || alignment > UINT16_MAX ||
        !pcm::validFormat(rate, static_cast<WORD>(channels), static_cast<WORD>(bits),
                          static_cast<WORD>(alignment), average)) return MF_E_INVALIDMEDIATYPE;
    format = {WAVE_FORMAT_PCM, static_cast<WORD>(channels), rate, average,
              static_cast<WORD>(alignment), static_cast<WORD>(bits), 0};
    unsigned emptyReads = 0;
    for (;;) {
        DWORD stream = 0, flags = 0;
        LONGLONG timestamp = 0;
        ComPtr<IMFSample> sample;
        hr = source->ReadSample(MF_SOURCE_READER_FIRST_AUDIO_STREAM, 0,
                               &stream, &flags, &timestamp, sample.out());
        if (FAILED(hr)) { logLine("Decode failed 0x%08lx", hr); return hr; }
        if (flags & (MF_SOURCE_READERF_ERROR | MF_SOURCE_READERF_CURRENTMEDIATYPECHANGED |
                     MF_SOURCE_READERF_NATIVEMEDIATYPECHANGED)) return MF_E_INVALIDMEDIATYPE;
        if (sample.p) {
            emptyReads = 0;
            ComPtr<IMFMediaBuffer> buffer;
            hr = sample->ConvertToContiguousBuffer(buffer.out());
            if (FAILED(hr)) return hr;
            BYTE* data = nullptr;
            DWORD length = 0;
            hr = buffer->Lock(&data, nullptr, &length);
            if (FAILED(hr)) return hr;
            if (length % format.nBlockAlign || length > pcm::maximumBytes - pcmData.size()) {
                buffer->Unlock(); return HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
            }
            try { if (length) pcmData.insert(pcmData.end(), data, data + length); }
            catch (...) { buffer->Unlock(); throw; }
            hr = buffer->Unlock();
            if (FAILED(hr)) return hr;
        } else if (++emptyReads > 10000) {
            return HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
        }
        if (flags & MF_SOURCE_READERF_ENDOFSTREAM) break;
    }
    if (pcmData.empty()) return HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
    logLine("Decoded PCM: rate=%lu channels=%u bytes=%zu duration_ms=%lu",
            format.nSamplesPerSec, format.nChannels, pcmData.size(),
            pcm::duration(pcmData.size(), format.nAvgBytesPerSec));
    return S_OK;
}

struct Reader {
    LegacyReader base{};
    LONG references = 1;
    LegacyCallback* callback = nullptr;
    void* context = nullptr;
    std::vector<BYTE> data;
    WAVEFORMATEX format{};
    std::atomic<std::size_t> offset{0};
    HANDLE cancel = nullptr, worker = nullptr;
    DWORD workerId = 0;
    CRITICAL_SECTION control;
    Reader() { InitializeCriticalSection(&control); }
    ~Reader() { DeleteCriticalSection(&control); }
};
static Reader* impl(LegacyReader* self) { return reinterpret_cast<Reader*>(self); }
static HRESULT WINAPI stop(LegacyReader* self);
static ULONG WINAPI addref(LegacyReader* self) { return InterlockedIncrement(&impl(self)->references); }
static ULONG WINAPI release(LegacyReader* self) {
    Reader* r = impl(self);
    LONG references = InterlockedDecrement(&r->references);
    if (!references) {
        stop(self);
        if (r->cancel) CloseHandle(r->cancel);
        if (r->callback) r->callback->vtable->release(r->callback);
        delete r;
    }
    return references;
}
static HRESULT WINAPI query(LegacyReader* self, REFIID iid, void** result) {
    if (!result) return E_POINTER;
    *result = nullptr;
    if (iid != IID_IUnknown) return E_NOINTERFACE;
    *result = self; addref(self); return S_OK;
}
static HRESULT WINAPI attribute(LegacyReader* self, const WCHAR* name,
                                DWORD* type, BYTE* value, WORD* bytes) {
    if (!name || !type || !bytes) return E_POINTER;
    if (wcscmp(name, L"Duration")) return E_INVALIDARG;
    WORD capacity = *bytes; *bytes = sizeof(DWORD); *type = 0;
    if (!value) return S_FALSE;
    if (capacity < sizeof(DWORD)) return static_cast<HRESULT>(0xc00d07d1u);
    DWORD duration = pcm::duration(impl(self)->data.size(), impl(self)->format.nAvgBytesPerSec);
    memcpy(value, &duration, sizeof(duration)); return S_OK;
}
static HRESULT WINAPI attributeCount(LegacyReader*, WORD* count) {
    if (!count) return E_POINTER;
    *count = 1;
    return S_OK;
}
static HRESULT WINAPI attributeIndex(LegacyReader* self, WORD index, WCHAR* name,
                                    WORD* nameChars, DWORD* type, BYTE* data, WORD* bytes) {
    if (index) return E_INVALIDARG;
    if (!nameChars) return E_POINTER;
    const WORD required = 9;
    WORD capacity = *nameChars; *nameChars = required;
    if (!name || capacity < required) return static_cast<HRESULT>(0xc00d07d1u);
    memcpy(name, L"Duration", required * sizeof(WCHAR));
    return attribute(self, name, type, data, bytes);
}
static HRESULT WINAPI getFormat(LegacyReader* self, WAVEFORMATEX* output, DWORD size) {
    if (!output) return E_POINTER;
    if (size < sizeof(WAVEFORMATEX)) return static_cast<HRESULT>(0xc00d07d1u);
    memcpy(output, &impl(self)->format, sizeof(WAVEFORMATEX)); return S_OK;
}
static DWORD WINAPI deliver(void* opaque) {
    Reader* r = static_cast<Reader*>(opaque);
    std::size_t offset = r->offset.load();
    const auto startOffset = offset;
    HRESULT result = S_OK;
    while (offset < r->data.size() && WaitForSingleObject(r->cancel, 0) != WAIT_OBJECT_0) {
        const DWORD length = static_cast<DWORD>(pcm::chunk(r->data.size() - offset, r->format.nBlockAlign));
        if (!length) { result = E_FAIL; break; }
        result = r->callback->vtable->sample(r->callback, r->data.data() + offset, length, r->context);
        if (FAILED(result)) break;
        offset += length;
        r->offset.store(offset);
    }
    // mmedia.unt signals its completion event when status == 3.
    r->callback->vtable->status(r->callback, 3, result, r->context);
    logLine("Delivery ended: bytes=%zu result=0x%08lx", offset - startOffset, result);
    return 0;
}
static HRESULT WINAPI stop(LegacyReader* self) {
    Reader* r = impl(self);
    EnterCriticalSection(&r->control);
    if (r->worker) {
        SetEvent(r->cancel);
        if (GetCurrentThreadId() == r->workerId) {
            LeaveCriticalSection(&r->control); return E_UNEXPECTED;
        }
        WaitForSingleObject(r->worker, INFINITE);
        CloseHandle(r->worker); r->worker = nullptr; r->workerId = 0;
    }
    LeaveCriticalSection(&r->control); return S_OK;
}
static HRESULT WINAPI start(LegacyReader* self) {
    Reader* r = impl(self);
    logLine("Start reader=%p offset=%zu", static_cast<void*>(self), r->offset.load());
    EnterCriticalSection(&r->control);
    if (r->worker) {
        if (WaitForSingleObject(r->worker, 0) != WAIT_OBJECT_0) {
            LeaveCriticalSection(&r->control); return E_UNEXPECTED;
        }
        CloseHandle(r->worker); r->worker = nullptr;
    }
    ResetEvent(r->cancel);
    r->worker = CreateThread(nullptr, 0, deliver, r, 0, &r->workerId);
    HRESULT result = r->worker ? S_OK : HRESULT_FROM_WIN32(GetLastError());
    LeaveCriticalSection(&r->control); return result;
}
static HRESULT WINAPI seek(LegacyReader* self, DWORD milliseconds) {
    logLine("Seek reader=%p milliseconds=%lu", static_cast<void*>(self), milliseconds);
    HRESULT hr = stop(self);
    if (FAILED(hr)) return hr;
    Reader* r = impl(self);
    r->offset.store(pcm::position(milliseconds, r->format.nAvgBytesPerSec,
                                 r->format.nBlockAlign, r->data.size()));
    return S_OK;
}
static const ReaderVtable vtable = {
    query, addref, release, attribute, attributeCount, attributeIndex,
    getFormat, start, stop, seek
};

extern "C" HRESULT WINAPI WMAudioCreateReader(const WCHAR* filename, LegacyCallback* callback,
                                             LegacyReader** result, void* context) {
    if (!result) return E_POINTER;
    *result = nullptr;
    if (!filename || !callback || !callback->vtable) return E_INVALIDARG;
    logLine("Compatibility reader v0.3: open requested pid=%lu", GetCurrentProcessId());
    WCHAR processPath[MAX_PATH] = {};
    if (GetModuleFileNameW(nullptr, processPath, MAX_PATH)) logPath("Process", processPath);
    WCHAR currentDirectory[MAX_PATH] = {};
    DWORD directoryLength = GetCurrentDirectoryW(MAX_PATH, currentDirectory);
    if (directoryLength && directoryLength < MAX_PATH) logPath("Working directory", currentDirectory);
    logPath("Requested WMA", filename);
    Reader* r = nullptr;
    try {
        r = new Reader;
        r->base.vtable = &vtable;
        std::wstring directory(processPath);
        const auto slash = directory.find_last_of(L"\\/");
        directory = slash == std::wstring::npos ? L"" : directory.substr(0, slash);
        const auto selected = bgm::selectPath(filename, directory, [](const std::wstring& path) {
            DWORD attributes = GetFileAttributesW(path.c_str());
            return attributes != INVALID_FILE_ATTRIBUTES && !(attributes & FILE_ATTRIBUTE_DIRECTORY);
        });
        logPath("Selected WMA", selected.c_str());
        // Prefer the original WMA folder even when an old converted root copy exists.
        // If the selected file is corrupt, report its error instead of hiding it.
        HRESULT hr = decode(selected.c_str(), r->data, r->format);
        if (FAILED(hr)) { delete r; logLine("Factory failed 0x%08lx", hr); return hr; }
        r->cancel = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        if (!r->cancel) { hr = HRESULT_FROM_WIN32(GetLastError()); delete r; return hr; }
        r->context = context;
        r->callback = callback;
        callback->vtable->addref(callback);
        *result = &r->base;
        return S_OK;
    } catch (const std::bad_alloc&) {
        if (r) { if (r->cancel) CloseHandle(r->cancel); delete r; }
        return E_OUTOFMEMORY;
    } catch (...) {
        if (r) { if (r->cancel) CloseHandle(r->cancel); delete r; }
        return E_FAIL;
    }
}

BOOL WINAPI DllMain(HINSTANCE module, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) dllModule = module;
    return TRUE;
}

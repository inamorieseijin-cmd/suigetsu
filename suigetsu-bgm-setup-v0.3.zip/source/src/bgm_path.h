#pragma once
#include <string>

namespace bgm {
inline bool trackName(const std::wstring& name) {
    if (name.size() != 10) return false;
    auto lower = [](wchar_t c) { return c >= L'A' && c <= L'Z' ? c + (L'a' - L'A') : c; };
    const wchar_t* pattern = L"bgm000.wma";
    for (std::size_t i = 0; i < name.size(); ++i) {
        if (i >= 3 && i <= 5) {
            if (name[i] < L'0' || name[i] > L'9') return false;
        } else if (lower(name[i]) != pattern[i]) return false;
    }
    return true;
}
template<class Exists>
std::wstring selectPath(const std::wstring& requested, const std::wstring& gameDirectory, Exists exists) {
    const auto slash = requested.find_last_of(L"\\/");
    const auto name = requested.substr(slash == std::wstring::npos ? 0 : slash + 1);
    if (!gameDirectory.empty() && trackName(name)) {
        const auto candidate = gameDirectory + L"\\WMA\\" + name;
        if (exists(candidate)) return candidate;
    }
    return requested;
}
}

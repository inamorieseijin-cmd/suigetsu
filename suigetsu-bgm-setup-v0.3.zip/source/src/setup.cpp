#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <commdlg.h>
#include <string>

static const WCHAR* title = L"水月 BGM互換セットアップ v0.3";
static bool exists(const std::wstring& path) {
    DWORD a = GetFileAttributesW(path.c_str());
    return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY);
}
static int fail(const WCHAR* text, DWORD error = GetLastError()) {
    WCHAR number[64]; wsprintfW(number, L"\n\nWindowsエラー番号: %lu", error);
    std::wstring message = text; message += number;
    MessageBoxW(nullptr, message.c_str(), title, MB_OK | MB_ICONERROR);
    return 1;
}
static bool writeFile(const std::wstring& path, const void* data, DWORD length) {
    HANDLE file = CreateFileW(path.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) return false;
    DWORD written = 0;
    bool okay = WriteFile(file, data, length, &written, nullptr) && written == length && FlushFileBuffers(file);
    DWORD error = okay ? ERROR_SUCCESS : GetLastError();
    CloseHandle(file);
    if (!okay) { DeleteFileW(path.c_str()); SetLastError(error); }
    return okay;
}
// Publish a fully written sibling file in one step. The prior DLL remains in
// place if writing or replacing it fails (for example, while the game runs).
static bool publish(const std::wstring& directory, const std::wstring& target, const void* data, DWORD length) {
    WCHAR temp[MAX_PATH];
    if (!GetTempFileNameW(directory.c_str(), L"swm", 0, temp)) return false;
    HANDLE file = CreateFileW(temp, GENERIC_WRITE, 0, nullptr, TRUNCATE_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) { DWORD e = GetLastError(); DeleteFileW(temp); SetLastError(e); return false; }
    DWORD written = 0;
    bool okay = WriteFile(file, data, length, &written, nullptr) && written == length && FlushFileBuffers(file);
    DWORD error = okay ? ERROR_SUCCESS : GetLastError();
    CloseHandle(file);
    if (okay) {
        okay = MoveFileExW(temp, target.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH);
        error = GetLastError();
    }
    if (!okay) { DeleteFileW(temp); SetLastError(error); }
    return okay;
}
int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, WCHAR*, int) {
    int action = MessageBoxW(nullptr,
        L"ゲームを終了してから操作してください。\n\n"
        L"「はい」：BGM互換DLLをインストール／更新\n"
        L"「いいえ」：このセットアップの初回実行前のDLLへ戻す\n"
        L"「キャンセル」：終了\n\n"
        L"曲はゲームのWMAフォルダーから読みます。動画は対象外です。",
        title, MB_YESNOCANCEL | MB_ICONINFORMATION);
    if (action == IDCANCEL) return 0;
    WCHAR selected[MAX_PATH] = {};
    OPENFILENAMEW dialog{};
    dialog.lStructSize = sizeof(dialog); dialog.lpstrFile = selected; dialog.nMaxFile = MAX_PATH;
    dialog.lpstrFilter = L"水月のゲームプログラム (advwin32*.exe)\0advwin32*.exe\0\0";
    dialog.lpstrTitle = L"ゲームフォルダー内の advwin32.exe または advwin32_.exe を選んでください";
    dialog.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    if (!GetOpenFileNameW(&dialog)) {
        DWORD e = CommDlgExtendedError();
        return e ? fail(L"ゲームの選択画面を開けませんでした。", e) : 0;
    }
    std::wstring path(selected);
    const auto slash = path.find_last_of(L'\\');
    if (slash == std::wstring::npos) return fail(L"ゲームの場所を確認できませんでした。", ERROR_BAD_PATHNAME);
    auto name = path.substr(slash + 1);
    if (_wcsicmp(name.c_str(), L"advwin32.exe") && _wcsicmp(name.c_str(), L"advwin32_.exe"))
        return fail(L"水月の advwin32.exe または advwin32_.exe を選んでください。", ERROR_INVALID_NAME);
    const auto directory = path.substr(0, slash);
    if (directory.size() + 64 >= MAX_PATH) return fail(L"フォルダーのパスが長すぎます。", ERROR_FILENAME_EXCED_RANGE);
    if (!exists(directory + L"\\mmedia.unt"))
        return fail(L"同じフォルダーに mmedia.unt がありません。ゲーム本体の場所を選んでください。", ERROR_FILE_NOT_FOUND);
    const auto target = directory + L"\\wmaudsdk.dll";
    const auto backupDirectory = directory + L"\\suigetsu-bgm-backup";
    const auto backup = backupDirectory + L"\\original.dll";
    const auto state = backupDirectory + L"\\state.txt";
    char baseline = 0;
    if (exists(state)) {
        HANDLE file = CreateFileW(state.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
        DWORD read = 0;
        bool okay = file != INVALID_HANDLE_VALUE && ReadFile(file, &baseline, 1, &read, nullptr) && read == 1 &&
                    GetFileSize(file, nullptr) == 1 && (baseline == 'P' || baseline == 'A');
        if (file != INVALID_HANDLE_VALUE) CloseHandle(file);
        if (!okay || (baseline == 'P' && !exists(backup)))
            return fail(L"復元用バックアップが不完全です。既存のDLLは変更していません。", ERROR_INVALID_DATA);
    }
    if (action == IDYES) {
        WIN32_FIND_DATAW track{};
        HANDLE search = FindFirstFileW((directory + L"\\WMA\\BGM???.WMA").c_str(), &track);
        if (search == INVALID_HANDLE_VALUE) return fail(L"WMAフォルダーにBGMファイルがありません。ゲームのインストール先を確認してください。");
        FindClose(search);
        auto message = L"次の場所へBGM互換DLLを配置します。\n\n" + directory +
            L"\n\n初回のDLLは自動保存します。BGMファイルは移動・変更しません。\n続けますか？";
        if (MessageBoxW(nullptr, message.c_str(), title, MB_OKCANCEL | MB_ICONQUESTION) != IDOK) return 0;
        if (!baseline) {
            if (!CreateDirectoryW(backupDirectory.c_str(), nullptr) && GetLastError() != ERROR_ALREADY_EXISTS)
                return fail(L"バックアップ用フォルダーを作れませんでした。配置先への書き込み権限を確認してください。");
            baseline = exists(target) ? 'P' : 'A';
            if (baseline == 'P' && !CopyFileW(target.c_str(), backup.c_str(), TRUE))
                return fail(L"現在のDLLをバックアップできませんでした。ゲームを終了して再実行してください。");
            if (!writeFile(state, &baseline, 1)) {
                DWORD e = GetLastError();
                if (baseline == 'P') DeleteFileW(backup.c_str());
                return fail(L"バックアップ情報を保存できませんでした。現在のDLLは変更していません。", e);
            }
        }
        HRSRC resource = FindResourceW(instance, MAKEINTRESOURCEW(1), RT_RCDATA);
        HGLOBAL loaded = resource ? LoadResource(instance, resource) : nullptr;
        const void* data = loaded ? LockResource(loaded) : nullptr;
        DWORD length = resource ? SizeofResource(instance, resource) : 0;
        if (!data || !length) return fail(L"セットアップ内のDLLが見つかりません。", ERROR_INVALID_DATA);
        if (!publish(directory, target, data, length))
            return fail(L"DLLを配置できませんでした。ゲームを終了し、必要ならセットアップを管理者として実行してください。");
        MessageBoxW(nullptr, L"インストールが完了しました。\n\n普段どおりゲームを起動して音楽テストを確認してください。\nWMAフォルダーの曲をそのまま使います。\n\n元へ戻すには、このセットアップを再実行して「いいえ」を選びます。",
                    title, MB_OK | MB_ICONINFORMATION);
    } else {
        if (!baseline) return fail(L"この場所にはセットアップのバックアップがありません。", ERROR_FILE_NOT_FOUND);
        if (MessageBoxW(nullptr, (L"初回実行前のDLLへ戻します。\n\n" + directory).c_str(), title,
                        MB_OKCANCEL | MB_ICONQUESTION) != IDOK) return 0;
        if (baseline == 'P') {
            // Copy via a sibling temp file; never truncate the current DLL first.
            WCHAR temp[MAX_PATH];
            if (!GetTempFileNameW(directory.c_str(), L"swm", 0, temp)) return fail(L"復元用ファイルを作れませんでした。");
            bool okay = CopyFileW(backup.c_str(), temp, FALSE) &&
                        MoveFileExW(temp, target.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH);
            DWORD e = GetLastError(); DeleteFileW(temp);
            if (!okay) return fail(L"DLLを復元できませんでした。ゲームを終了して再実行してください。", e);
        } else if (exists(target) && !DeleteFileW(target.c_str())) return fail(L"互換DLLを取り除けませんでした。ゲームを終了してください。");
        MessageBoxW(nullptr, L"初回実行前のDLLの状態へ戻しました。\nバックアップは残しています。", title, MB_OK | MB_ICONINFORMATION);
    }
    return 0;
}

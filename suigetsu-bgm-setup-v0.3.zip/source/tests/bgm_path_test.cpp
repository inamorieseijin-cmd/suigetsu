#include "../src/bgm_path.h"
#include <cassert>
#include <iostream>
int main() {
    const std::wstring directory = L"D:\\水月 新しい場所";
    const std::wstring source = directory + L"\\WMA\\BGM002.WMA";
    auto exists = [&](const std::wstring& path) { return path == source; };
    assert(bgm::selectPath(L"D:\\old\\BGM002.WMA", directory, exists) == source);
    assert(bgm::selectPath(L"BGM002.WMA", directory, exists) == source);
    assert(bgm::selectPath(directory + L"\\BGM002.WMA", directory, exists) == source);
    assert(bgm::selectPath(L"BGM001.WMA", directory, exists) == L"BGM001.WMA");
    assert(bgm::selectPath(L"other.WMA", directory, exists) == L"other.WMA");
    assert(bgm::trackName(L"bgm020.wma"));
    assert(!bgm::trackName(L"BGM../.WMA"));
    assert(!bgm::trackName(L"BGM0000.WMA"));
    std::cout << "PASS: WMA-folder priority, stale/relative paths, missing track and Unicode directory\n";
}

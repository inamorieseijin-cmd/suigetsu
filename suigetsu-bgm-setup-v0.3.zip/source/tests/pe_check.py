"""Validate the actual packaged Windows binaries, not an implementation mock."""
from pathlib import Path
import re
import subprocess
import struct

root = Path(__file__).resolve().parents[1]
for name in ("wmaudsdk.dll", "selftest.exe", "suigetsu-bgm-setup.exe"):
    path = root / "package" / name
    data = path.read_bytes()
    assert data[:2] == b"MZ"
    header = struct.unpack_from("<I", data, 0x3C)[0]
    assert data[header:header + 4] == b"PE\0\0"
    assert struct.unpack_from("<H", data, header + 4)[0] == 0x14C, "not x86"
    assert struct.unpack_from("<H", data, header + 24)[0] == 0x10B, "not PE32"
    output = subprocess.check_output(["objdump", "-p", str(path)], text=True)
    imports = {s.lower() for s in re.findall(r"DLL Name: (\S+)", output)}
    assert not imports & {"strmdll.dll", "msaud32.acm", "drmclien.dll", "wmaudsdk.dll"}
    assert not any(s.startswith(("libgcc", "libstdc++", "libwinpthread")) for s in imports)
    assert imports <= {"kernel32.dll", "mfplat.dll", "mfreadwrite.dll", "msvcrt.dll", "ole32.dll", "winmm.dll", "comdlg32.dll", "user32.dll"}
    if name.endswith(".dll"):
        assert "WMAudioCreateReader" in output
        assert "mfreadwrite.dll" in imports and "mfplat.dll" in imports
        count = re.search(r"Export Address Table\s+([0-9a-fA-F]{8})", output)
        assert count and int(count.group(1), 16) == 1, "unexpected exports"
    print(f"PASS: {name}: x86/PE32, exports and Windows-only dependencies")

# Verify that the standalone installer contains exactly the DLL we validated,
# rather than a stale build, and that it requests no automatic elevation.
data = (root / "package" / "suigetsu-bgm-setup.exe").read_bytes()
header = struct.unpack_from("<I", data, 0x3C)[0]
optional = header + 24
resource_rva = struct.unpack_from("<I", data, optional + 96 + 2 * 8)[0]
section_table = optional + struct.unpack_from("<H", data, header + 20)[0]
sections = []
for i in range(struct.unpack_from("<H", data, header + 6)[0]):
    at = section_table + i * 40
    size, rva, raw_size, raw = struct.unpack_from("<IIII", data, at + 8)
    sections.append((rva, max(size, raw_size), raw))
def offset(rva):
    for start, size, raw in sections:
        if start <= rva < start + size:
            return raw + rva - start
    raise AssertionError("resource outside PE sections")
base = offset(resource_rva)
def entry(directory, identifier=None):
    named, numbered = struct.unpack_from("<HH", data, base + directory + 12)
    for i in range(named + numbered):
        key, value = struct.unpack_from("<II", data, base + directory + 16 + i * 8)
        if identifier is None or key == identifier:
            return value
    raise AssertionError("missing installer resource")
def resource(kind):
    folder = entry(0, kind)
    assert folder & 0x80000000
    folder = entry(folder & 0x7fffffff, 1)
    assert folder & 0x80000000
    leaf = entry(folder & 0x7fffffff)
    assert not leaf & 0x80000000
    rva, length = struct.unpack_from("<II", data, base + leaf)
    return data[offset(rva):offset(rva) + length]
assert resource(10) == (root / "package" / "wmaudsdk.dll").read_bytes()
assert b'level="asInvoker"' in resource(24)
print("PASS: installer embeds the current DLL and the no-elevation manifest")

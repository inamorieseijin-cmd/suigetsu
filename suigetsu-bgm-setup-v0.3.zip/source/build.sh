#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p package
CXX_WINDOWS="${CXX_WINDOWS:-i686-w64-mingw32-g++}"
common=(-std=c++17 -O2 -Wall -Wextra -Werror -static-libgcc -static-libstdc++)
"$CXX_WINDOWS" "${common[@]}" -shared src/wma_compat.cpp src/exports.def \
    -o package/wmaudsdk.dll -lmfreadwrite -lmfplat -lmfuuid -lole32 -luuid -static -lwinpthread
"$CXX_WINDOWS" "${common[@]}" -municode tests/windows_selftest.cpp \
    -o package/selftest.exe -lwinmm -static -lwinpthread
g++ -std=c++17 -O2 -Wall -Wextra -Werror tests/pcm_core_test.cpp -o /tmp/suigetsu-pcm-core-test
/tmp/suigetsu-pcm-core-test
g++ -std=c++17 -O2 -Wall -Wextra -Werror tests/bgm_path_test.cpp -o /tmp/suigetsu-bgm-path-test
/tmp/suigetsu-bgm-path-test
STRIP_WINDOWS="${STRIP_WINDOWS:-i686-w64-mingw32-strip}"
"$STRIP_WINDOWS" package/wmaudsdk.dll package/selftest.exe
WINDRES="${WINDRES:-i686-w64-mingw32-windres}"
"$WINDRES" -I . src/setup.rc -o package/setup-resource.o
"$CXX_WINDOWS" "${common[@]}" -municode -mwindows -finput-charset=UTF-8 src/setup.cpp package/setup-resource.o \
    -o package/suigetsu-bgm-setup.exe -lcomdlg32 -static -lwinpthread
"$STRIP_WINDOWS" package/suigetsu-bgm-setup.exe
python3 tests/pe_check.py

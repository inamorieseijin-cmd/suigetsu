#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <mmsystem.h>
#include <cstdio>
#include <vector>
#include <algorithm>
#include "../src/legacy.h"
#include "../src/pcm_core.h"

struct Callback {
    LegacyCallback base;
    LONG references = 1;
    HANDLE done = nullptr;
    std::vector<BYTE> data;
    HRESULT result = E_PENDING;
    bool badContext = false;
};
static Callback* impl(LegacyCallback* c) { return reinterpret_cast<Callback*>(c); }
static HRESULT WINAPI query(LegacyCallback*, REFIID, void** p) {
    if (p) *p = nullptr;
    return E_NOINTERFACE;
}
static ULONG WINAPI addref(LegacyCallback* c) { return InterlockedIncrement(&impl(c)->references); }
static ULONG WINAPI release(LegacyCallback* c) { return InterlockedDecrement(&impl(c)->references); }
static HRESULT WINAPI sample(LegacyCallback* c, BYTE* data, DWORD length, void* context) {
    Callback* cb = impl(c);
    if (context != cb) { cb->badContext = true; return E_INVALIDARG; }
    try { cb->data.insert(cb->data.end(), data, data + length); }
    catch (...) { return E_OUTOFMEMORY; }
    return S_OK;
}
static HRESULT WINAPI status(LegacyCallback* c, DWORD code, HRESULT hr, void* context) {
    Callback* cb = impl(c);
    if (context != cb) cb->badContext = true;
    if (code == 3) { cb->result = hr; SetEvent(cb->done); }
    return S_OK;
}
static const CallbackVtable callbackVtable = {query, addref, release, sample, status};

static bool require(bool condition, const char* message) {
    std::printf("%s: %s\n", condition ? "PASS" : "FAIL", message);
    return condition;
}
static bool collect(LegacyReader* r, Callback& callback) {
    callback.data.clear(); callback.result = E_PENDING;
    ResetEvent(callback.done);
    HRESULT hr = r->vtable->start(r);
    if (!require(SUCCEEDED(hr), "reader start")) return false;
    bool finished = WaitForSingleObject(callback.done, 15000) == WAIT_OBJECT_0;
    r->vtable->stop(r);
    return require(finished && SUCCEEDED(callback.result) && !callback.badContext,
                   "asynchronous samples, EOF status and callback context");
}
static bool play(const WAVEFORMATEX& format, std::vector<BYTE>& data) {
    HANDLE done = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    if (!done) return false;
    HWAVEOUT wave = nullptr;
    MMRESULT result = waveOutOpen(&wave, WAVE_MAPPER, &format,
                                  reinterpret_cast<DWORD_PTR>(done), 0, CALLBACK_EVENT);
    if (result) { CloseHandle(done); return require(false, "Windows audio device open"); }
    WAVEHDR header{};
    header.lpData = reinterpret_cast<char*>(data.data());
    header.dwBufferLength = static_cast<DWORD>(std::min<std::size_t>(data.size(), format.nAvgBytesPerSec * 3));
    bool prepared = waveOutPrepareHeader(wave, &header, sizeof(header)) == MMSYSERR_NOERROR;
    bool written = prepared && waveOutWrite(wave, &header, sizeof(header)) == MMSYSERR_NOERROR;
    const ULONGLONG deadline = GetTickCount64() + 6000;
    while (written && !(header.dwFlags & WHDR_DONE) && GetTickCount64() < deadline)
        WaitForSingleObject(done, 100);
    bool completed = written && (header.dwFlags & WHDR_DONE);
    waveOutReset(wave);
    if (prepared) waveOutUnprepareHeader(wave, &header, sizeof(header));
    waveOutClose(wave); CloseHandle(done);
    return require(completed, "three-second audio output (confirm sound by listening)");
}

int wmain(int argc, WCHAR** argv) {
    if (argc != 2) { std::puts("Usage: selftest.exe <original BGMxxx.WMA>"); return 2; }
    WCHAR dllPath[MAX_PATH];
    if (!GetModuleFileNameW(nullptr, dllPath, MAX_PATH)) return 2;
    WCHAR* slash = wcsrchr(dllPath, L'\\');
    if (!slash || slash - dllPath + 1 + 12 >= MAX_PATH) return 2;
    wcscpy(slash + 1, L"wmaudsdk.dll");
    HMODULE module = LoadLibraryW(dllPath);
    if (!require(module != nullptr, "load trial DLL next to selftest")) return 1;
    FARPROC address = GetProcAddress(module, "WMAudioCreateReader");
    CreateReader create = nullptr;
    static_assert(sizeof(create) == sizeof(address), "Unexpected function pointer size");
    memcpy(&create, &address, sizeof(create));
    if (!require(create != nullptr, "legacy undecorated export")) { FreeLibrary(module); return 1; }
    Callback cb{}; cb.base.vtable = &callbackVtable;
    cb.done = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (!cb.done) { FreeLibrary(module); return 1; }
    LegacyReader* reader = nullptr;
    HRESULT hr = create(argv[1], &cb.base, &reader, &cb);
    std::printf("Factory result: 0x%08lx\n", static_cast<unsigned long>(hr));
    bool okay = require(SUCCEEDED(hr) && reader != nullptr, "decode original WMA using Media Foundation");
    if (okay) {
        WAVEFORMATEX format{};
        okay = require(SUCCEEDED(reader->vtable->format(reader, &format, sizeof(format))) &&
                        pcm::validFormat(format.nSamplesPerSec, format.nChannels,
                        format.wBitsPerSample, format.nBlockAlign, format.nAvgBytesPerSec), "PCM format contract");
        DWORD duration = 0, type = 99; WORD bytes = sizeof(duration);
        okay = require(SUCCEEDED(reader->vtable->attribute(reader, L"Duration", &type,
                        reinterpret_cast<BYTE*>(&duration), &bytes)) && type == 0 && bytes == 4 && duration > 0,
                        "duration attribute contract") && okay;
        if (okay && collect(reader, cb)) {
            auto original = cb.data;
            okay = require(!original.empty() && original.size() % format.nBlockAlign == 0,
                           "complete aligned PCM samples") && okay;
            const DWORD middle = duration / 2;
            okay = require(SUCCEEDED(reader->vtable->seek(reader, middle)), "seek while stopped") && okay;
            if (collect(reader, cb)) {
                const auto position = pcm::position(middle, format.nAvgBytesPerSec,
                                                     format.nBlockAlign, original.size());
                okay = require(cb.data.size() == original.size() - position &&
                               std::equal(cb.data.begin(), cb.data.end(), original.begin() + position),
                               "seek returns the exact remaining PCM") && okay;
            } else okay = false;
            okay = require(SUCCEEDED(reader->vtable->seek(reader, 0)), "rewind for loop") && okay;
            if (collect(reader, cb))
                okay = require(cb.data == original, "loop restart reproduces identical PCM") && okay;
            else okay = false;
            if (okay) okay = play(format, original);
        } else okay = false;
        reader->vtable->release(reader);
        okay = require(cb.references == 1, "callback reference released") && okay;
    }
    CloseHandle(cb.done); FreeLibrary(module);
    std::puts(okay ? "SELFTEST PASSED. Game integration is still unverified." : "SELFTEST FAILED. Do not install into the game.");
    return okay ? 0 : 1;
}

#include "../src/pcm_core.h"
#include <cassert>
#include <limits>
#include <cstdio>

int main() {
    assert(pcm::validFormat(44100, 2, 16, 4, 176400));
    assert(pcm::validFormat(22050, 1, 16, 2, 44100));
    assert(!pcm::validFormat(44100, 2, 32, 8, 352800));
    assert(!pcm::validFormat(44100, 2, 16, 2, 176400));
    assert(!pcm::validFormat(44100, 2, 16, 4, 176401));
    assert(!pcm::validFormat(0, 2, 16, 4, 0));
    assert(!pcm::validFormat(44100, 6, 16, 12, 529200));
    assert(pcm::duration(176400 * 3, 176400) == 3000);
    assert(pcm::duration(176400 * 3, 0) == 0);
    assert(pcm::position(1500, 176400, 4, 176400 * 3) == 264600);
    assert(pcm::position(UINT32_MAX, 176400, 4, 176400 * 3) == 529200);
    assert(pcm::position(1, 176400, 4, 176400 * 3) == 176);
    assert(pcm::position(1500, 176400, 0, 176400 * 3) == 0);
    std::size_t remaining = 176400 * 3;
    unsigned chunks = 0;
    while (remaining) {
        const auto count = pcm::chunk(remaining, 4);
        assert(count && count <= remaining && count <= 65536 && count % 4 == 0);
        remaining -= count; ++chunks;
    }
    assert(chunks == 9);
    assert(pcm::chunk(0, 4) == 0);
    assert(pcm::chunk(16, 0) == 0);
    std::puts("PASS: PCM format validation, seek bounds, alignment and complete chunk delivery");
}

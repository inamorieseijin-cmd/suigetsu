"""Validate the actual packaged Windows binaries, not an implementation mock."""
from pathlib import Path
import re
import subprocess
import struct

root = Path(__file__).resolve().parents[1]
for name in ("wmaudsdk.dll", "selftest.exe"):
    path = root / "package" / name
    data = path.read_bytes()
    assert data[:2] == b"MZ"
    header = struct.unpack_from("<I", data, 0x3C)[0]
    assert data[header:header + 4] == b"PE\0\0"
    assert struct.unpack_from("<H", data, header + 4)[0] == 0x14C, "not x86"
    assert struct.unpack_from("<H", data, header + 24)[0] == 0x10B, "not PE32"
    output = subprocess.check_output(["objdump", "-p", str(path)], text=True)
    imports = {s.lower() for s in re.findall(r"DLL Name: (\S+)", output)}
    assert not imports & {"strmdll.dll", "msaud32.acm", "drmclien.dll", "wmaudsdk.dll"}
    assert not any(s.startswith(("libgcc", "libstdc++", "libwinpthread")) for s in imports)
    assert imports <= {"kernel32.dll", "mfplat.dll", "mfreadwrite.dll", "msvcrt.dll", "ole32.dll", "winmm.dll"}
    if name.endswith(".dll"):
        assert "WMAudioCreateReader" in output
        assert "mfreadwrite.dll" in imports and "mfplat.dll" in imports
        count = re.search(r"Export Address Table\s+([0-9a-fA-F]{8})", output)
        assert count and int(count.group(1), 16) == 1, "unexpected exports"
    print(f"PASS: {name}: x86/PE32, exports and Windows-only dependencies")

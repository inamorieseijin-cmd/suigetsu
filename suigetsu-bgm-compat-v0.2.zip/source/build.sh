#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p package
CXX_WINDOWS="${CXX_WINDOWS:-i686-w64-mingw32-g++}"
common=(-std=c++17 -O2 -Wall -Wextra -Werror -static-libgcc -static-libstdc++)
"$CXX_WINDOWS" "${common[@]}" -shared src/wma_compat.cpp src/exports.def \
    -o package/wmaudsdk.dll -lmfreadwrite -lmfplat -lmfuuid -lole32 -luuid -static -lwinpthread
"$CXX_WINDOWS" "${common[@]}" -municode tests/windows_selftest.cpp \
    -o package/selftest.exe -lwinmm -static -lwinpthread
g++ -std=c++17 -O2 -Wall -Wextra -Werror tests/pcm_core_test.cpp -o /tmp/suigetsu-pcm-core-test
/tmp/suigetsu-pcm-core-test

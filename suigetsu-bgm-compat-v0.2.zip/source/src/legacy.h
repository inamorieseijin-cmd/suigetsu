#pragma once
#include <windows.h>
#include <mmreg.h>
#include <cstddef>

// The 32-bit stdcall layout observed in the supplied mmedia.unt.
struct LegacyCallback;
struct LegacyReader;
struct CallbackVtable {
    HRESULT (WINAPI *query)(LegacyCallback*, REFIID, void**);
    ULONG (WINAPI *addref)(LegacyCallback*);
    ULONG (WINAPI *release)(LegacyCallback*);
    HRESULT (WINAPI *sample)(LegacyCallback*, BYTE*, DWORD, void*);
    HRESULT (WINAPI *status)(LegacyCallback*, DWORD, HRESULT, void*);
};
struct LegacyCallback { const CallbackVtable* vtable; };
struct ReaderVtable {
    HRESULT (WINAPI *query)(LegacyReader*, REFIID, void**);
    ULONG (WINAPI *addref)(LegacyReader*);
    ULONG (WINAPI *release)(LegacyReader*);
    HRESULT (WINAPI *attribute)(LegacyReader*, const WCHAR*, DWORD*, BYTE*, WORD*);
    HRESULT (WINAPI *attributeCount)(LegacyReader*, WORD*);
    HRESULT (WINAPI *attributeIndex)(LegacyReader*, WORD, WCHAR*, WORD*, DWORD*, BYTE*, WORD*);
    HRESULT (WINAPI *format)(LegacyReader*, WAVEFORMATEX*, DWORD);
    HRESULT (WINAPI *start)(LegacyReader*);
    HRESULT (WINAPI *stop)(LegacyReader*);
    HRESULT (WINAPI *seek)(LegacyReader*, DWORD);
};
struct LegacyReader { const ReaderVtable* vtable; };
using CreateReader = HRESULT (WINAPI *)(const WCHAR*, LegacyCallback*, LegacyReader**, void*);
static_assert(sizeof(void*) == 4, "This ABI must be compiled for 32-bit Windows");
static_assert(sizeof(WAVEFORMATEX) == 18, "Unexpected PCM header layout");
static_assert(offsetof(ReaderVtable, format) == 0x18, "Incorrect reader slots");
static_assert(offsetof(ReaderVtable, seek) == 0x24, "Incorrect reader slots");

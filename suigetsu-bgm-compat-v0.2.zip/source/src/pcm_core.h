#pragma once
#include <cstddef>
#include <cstdint>
#include <algorithm>

namespace pcm {
constexpr std::size_t maximumBytes = 128u * 1024u * 1024u;
inline bool validFormat(std::uint32_t rate, std::uint16_t channels,
                        std::uint16_t bits, std::uint16_t align, std::uint32_t average) {
    return rate >= 8000 && rate <= 192000 && (channels == 1 || channels == 2) &&
           bits == 16 && align == channels * 2 && average == rate * align;
}
inline std::size_t position(std::uint32_t milliseconds, std::uint32_t average,
                            std::uint16_t align, std::size_t length) {
    if (!average || !align) return 0;
    const std::uint64_t value = static_cast<std::uint64_t>(milliseconds) * average / 1000;
    const auto result = static_cast<std::size_t>(std::min<std::uint64_t>(value, length));
    return result - result % align;
}
inline std::uint32_t duration(std::size_t length, std::uint32_t average) {
    return average ? static_cast<std::uint32_t>(static_cast<std::uint64_t>(length) * 1000 / average) : 0;
}
inline std::size_t chunk(std::size_t remaining, std::uint16_t align) {
    if (!align) return 0;
    const auto value = std::min<std::size_t>(remaining, 65536);
    return value - value % align;
}
}

@echo off
setlocal
cd /d "%~dp0"
set "bgm_dir=D:\SUIGETSU\WMA"
if not "%~1"=="" set "bgm_dir=%~1"
echo Standalone test: no game files will be changed.
echo Each successful test plays three seconds of music.
selftest.exe "%bgm_dir%\BGM001.WMA" > test-results.txt 2>&1
set "test_code=%ERRORLEVEL%"
type test-results.txt
if not "%test_code%"=="0" goto finish
selftest.exe "%bgm_dir%\BGM002.WMA" >> test-results.txt 2>&1
set "test_code=%ERRORLEVEL%"
type test-results.txt
:finish
echo.
echo Test exit code: %test_code%
echo Send test-results.txt and say whether you heard the music.
pause
exit /b %test_code%
